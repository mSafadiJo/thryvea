

<?php $__env->startSection('content'); ?>
<!-- Page 1-->
<div class="row">
    <div class="col-lg-12">
        <div class="card-box page-title-box">
            <h4 class="header-title">Buyers Campaigns</h4>
        </div>
    </div>
</div>
<link rel="stylesheet" href="https://unpkg.com/balloon-css/balloon.min.css">
<div class="row">
    <div class="col-lg-12">
        <div class="card-box">
            <div class="panel">
                <div class="panel-heading bord-btm clearfix pad-all h-100">
                    <h3 class="panel-title pull-left pad-no"><?php echo e(__('List OF Campaigns')); ?></h3>
                    
                        
                            
                                
                                    
                                        
                                        
                                        
                                        
                                        
                                    
                                
                            
                            
                                
                                    
                                
                            
                        
                    
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div id="dataAjaxTableCampaign">
                        
                        <table id="datatable" class="table table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Campaign Name</th>
                                <th>Created At</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if( !empty($users) ): ?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($val->id); ?></td>
                                        <td><?php echo e($val->user_business_name); ?></td>
                                        <td><?php echo e($val->created_at); ?></td>
                                        <td>
                                            <a href="/Admin/Campaign/<?php echo e($val->id); ?>" class="on-default edit-row" data-toggle="tooltip" data-placement="top" title="" data-original-title="List Of Campaign" data-trigger="hover" data-animation="false">
                                                <i class="fa fa-list-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        
                            
                                
                            
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Of Page 1-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\safadi\allieddigitalmediaNew\resources\views/Admin/Campaign/list_of_business.blade.php ENDPATH**/ ?>