<!-- App favicon -->
<meta content="<?php echo e(config('app.name', 'Laravel')); ?>" name="description" />


<!-- App css -->
<link href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(URL::asset('css/icons.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(URL::asset('css/metismenu.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(URL::asset('css/style.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('css/custom-style.css')); ?>" rel="stylesheet" type="text/css" />

<?php if(Config::get('app.name') == 'Zone1Remodeling'): ?>
    <link rel="shortcut icon" href="<?php echo e(asset('images/zone1iconblack.svg')); ?>">
    <link href="<?php echo e(URL::asset('css/zoneLogin.css')); ?>" rel="stylesheet" type="text/css" />
<?php else: ?>
    <link rel="shortcut icon" href="<?php echo e(asset('images/Allied/icon.ico')); ?>">
    <link href="<?php echo e(URL::asset('css/newLogin.css')); ?>" rel="stylesheet" type="text/css" />
<?php endif; ?>



<link href="<?php echo e(URL::asset('plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(URL::asset('plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(URL::asset('plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />


<link href="<?php echo e(URL::asset('plugins/timepicker/bootstrap-timepicker.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('plugins/clockpicker/css/bootstrap-clockpicker.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('plugins/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet">

<link href="<?php echo e(URL::asset('plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css">
<!-- tags input-->

<link href="<?php echo e(URL::asset('plugins/bootstrap-tagsinput/css/bootstrap-tagsinput.css')); ?>" rel="stylesheet" type="text/css">

<link href="<?php echo e(URL::asset('plugins/magnific-popup/css/magnific-popup.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet" type="text/css" />

<?php if(Config::get('app.name') == 'Zone1Remodeling'): ?>
    <?php if( !empty(Auth::user()->role_id) ): ?>
        <?php if( Auth::user()->role_id != 1 && Auth::user()->role_id != 2 ): ?>
            <link href="<?php echo e(asset('css/zoneBuyersDashbord.css')); ?>" rel="stylesheet" type="text/css" />
        <?php endif; ?>
    <?php endif; ?>
<?php else: ?>
    <?php if( !empty(Auth::user()->role_id) ): ?>
        <?php if( Auth::user()->role_id != 1 && Auth::user()->role_id != 2 ): ?>
            <link href="<?php echo e(asset('css/buyersDashbord.css')); ?>" rel="stylesheet" type="text/css" />
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>

<?php if( !empty(Auth::user()->role_id) ): ?>
    <?php if( Auth::user()->role_id == 1 || Auth::user()->role_id == 2 ): ?>
        <link href="<?php echo e(asset('css/admin-custom-style.css')); ?>" rel="stylesheet" type="text/css" />
    <?php endif; ?>
<?php endif; ?>

<!-- map files -->
<link href="<?php echo e(asset('css/hot-map.css')); ?>" rel="stylesheet" type="text/css" />
<?php /**PATH C:\Users\admin\Desktop\safadi\allieddigitalmediaNew\resources\views/include/include_css.blade.php ENDPATH**/ ?>