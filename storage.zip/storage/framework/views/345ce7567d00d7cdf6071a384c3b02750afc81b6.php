<?php $__env->startSection('content'); ?>
    <!-- Page 1-->
    <div class="row">
        <div class="col-lg-12">
            <div class="card-box page-title-box">
                <h4 class="header-title">Campaigns</h4>
            </div>
        </div>
    </div>
    <?php
        $permission_users = array();
        if( !empty(Auth::user()->permission_users) ){
            $permission_users = json_decode(Auth::user()->permission_users, true);
        }
    ?>
    <link rel="stylesheet" href="https://unpkg.com/balloon-css/balloon.min.css">
    
    <div class="loader" style="display: none;"></div>

    <div class="un_loading_loader">
        <div class="row">
            <div class="col-lg-12">
                <div class="card-box">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="service_id">Service Name</label>
                                        <select class="select2 form-control select2-multiple" multiple name="service_id[]" id="service_id" data-placeholder="Choose ...">
                                            <optgroup label="Service">
                                                <?php if( !empty( $data['services'] ) ): ?>
                                                    <?php $__currentLoopData = $data['services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($service->service_campaign_id); ?>"><?php echo e($service->service_campaign_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </optgroup>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="buyer_id">Buyers</label>
                                        <select class="select2 form-control select2-multiple" multiple name="buyer_id[]" id="buyer_id" data-placeholder="Choose ...">
                                            <optgroup label="Buyer Name">
                                                <?php if( !empty( $data['buyers'] ) ): ?>
                                                    <?php $__currentLoopData = $data['buyers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($buyer->id); ?>"
                                                            <?php if( $data['id'] == $buyer->id ): ?> selected <?php endif; ?>><?php echo e($buyer->user_business_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </optgroup>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <label for="buyer_id">.</label>
                                    <button type="button" class="btn btn-primary col-lg-12" id="FilterCampaignAdmainAjax">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div style="margin-bottom: 5%;"></div>
                    <!--Panel heading-->

                    <div class="row">
                        <div class="col-lg-6">
                            <h6>List Of Campaigns</h6>
                        </div>
                        <div class="col-lg-6 pull-right">
                            <?php if( empty($permission_users) || in_array('7-1', $permission_users) ): ?>
                                <a href="/AdminCampaignCreate?buyer_id=<?php echo e($data['id']); ?>" class="btn btn-rounded btn-info pull-right"><i class="fa fa-plus"></i> <?php echo e(__('Add New Campaign')); ?></a>
                            <?php endif; ?>
                            <?php if( empty($permission_users) || in_array('7-4', $permission_users) ): ?>
                                <form action="<?php echo e(route('Admin_Campaign_Export')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <button type="submit" style="margin-right: 1%;" class="btn btn-rounded btn-info pull-right"><i class="fa fa-download"></i> Export Data</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-lg-12">
                            <div id="dataAjaxTableCampaign">
                                <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="datatable">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Campaign Name</th>
                                        <th>Campaign Type</th>
                                        <th>Buyer</th>
                                        <th>Service</th>
                                        <th>Created At</th>
                                        <th>Status</th>
                                        <th>Active</th>
                                        <?php if( empty($permission_users) || in_array('7-1', $permission_users) || in_array('7-2', $permission_users) || in_array('7-3', $permission_users) || in_array('7-6', $permission_users) || in_array('7-7', $permission_users)): ?>
                                            <th>Action</th>
                                        <?php endif; ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if( !empty($campaigns) ): ?>
                                        <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($campaign->campaign_id); ?></td>
                                                <td><?php echo e($campaign->campaign_name); ?></td>
                                                <td><?php echo e($campaign->campaign_types_name); ?></td>
                                                <td><?php echo e($campaign->user_business_name); ?></td>
                                                <td><?php echo e($campaign->service_campaign_name); ?></td>
                                                <td><?php echo e(date('Y/m/d', strtotime($campaign->created_at))); ?></td>
                                                <?php if( empty($permission_users) || in_array('7-2', $permission_users) ): ?>
                                                    <td>
                                                        <select name="campaign_status" class="form-control" style="height: unset;width: 80%;" id="admincampaign_status_table_Ajax_changing-<?php echo e($campaign->campaign_id); ?>"
                                                                onchange="return admincampaign_status_table_Ajax_changing('<?php echo e($campaign->campaign_id); ?>');"
                                                            <?php if( !( empty($permission_users) || in_array('7-5', $permission_users) ) && $campaign->campaign_status_id == 3 ): ?> disabled <?php endif; ?> >
                                                            <?php if(!empty($campaign_status)): ?>
                                                                <?php $__currentLoopData = $campaign_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if( $status->campaign_status_id == 3 ): ?>
                                                                        <?php if( $campaign->campaign_status_id == 3 ): ?>
                                                                            <option value="<?php echo e($status->campaign_status_id); ?>-<?php echo e($campaign->campaign_id); ?>"
                                                                                <?php if( $campaign->campaign_status_id == $status->campaign_status_id ): ?> selected <?php endif; ?>
                                                                            ><?php echo e($status->campaign_status_name); ?></option>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                            <option value="<?php echo e($status->campaign_status_id); ?>-<?php echo e($campaign->campaign_id); ?>"
                                                                                <?php if( $campaign->campaign_status_id == $status->campaign_status_id ): ?> selected <?php endif; ?>
                                                                            ><?php echo e($status->campaign_status_name); ?></option>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </select>
                                                    </td>
                                                <?php else: ?>
                                                    <?php if($campaign->campaign_status_id == 1): ?>
                                                        <td>Running</td>
                                                    <?php elseif($campaign->campaign_status_id == 3): ?>
                                                        <td>Pending</td>
                                                    <?php elseif($campaign->campaign_status_id == 4): ?>
                                                        <td>Pause</td>
                                                    <?php else: ?>
                                                        <td>Stopped</td>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <td>
                                                    <?php if( $campaign->campaign_visibility == 1 ): ?>
                                                        Active
                                                    <?php else: ?>
                                                        Not Active
                                                    <?php endif; ?>
                                                </td>
                                                <?php if( empty($permission_users) || in_array('7-1', $permission_users) || in_array('7-2', $permission_users) || in_array('7-3', $permission_users) || in_array('7-6', $permission_users) || in_array('7-7', $permission_users) ): ?>
                                                    <td>
                                                        <?php if( $campaign->campaign_visibility == 1 ): ?>
                                                            
                                                                
                                                            
                                                            <?php if( empty($permission_users) || in_array('7-2', $permission_users) || in_array('7-7', $permission_users) ): ?>
                                                                <a href="<?php echo e(route("ShowAdminCampaignEdit", $campaign->campaign_id)); ?>" class="on-default edit-row" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit" data-trigger="hover" data-animation="false">
                                                                    <i class="fa fa-pencil"></i>
                                                                </a>
                                                                <a href="<?php echo e(route("Admin.Campaign.ZipCodes.List", $campaign->campaign_id)); ?>" class="on-default edit-row" data-toggle="tooltip" data-placement="top" title="" data-original-title="List OF ZipCodes" data-trigger="hover" data-animation="false">
                                                                    <i class="fa fa-list"></i>
                                                                </a>
                                                            <?php endif; ?>
                                                            <?php if( empty($permission_users) || in_array('7-2', $permission_users) ): ?>
                                                                <span style="cursor: pointer;" class="on-default remove-row" data-toggle="tooltip" data-placement="top" title="" data-original-title="CallTolls Campaign Id" data-trigger="hover" data-animation="false">
                                                                    <i class="fa fa-pencil-square" data-toggle="modal" data-target="#campaign_file_id"
                                                                       onclick="return openmenufunctioncampaign_file('<?php echo e($campaign->campaign_id); ?>', '<?php echo e($campaign->file_calltools_id); ?>', '<?php echo e($campaign->campaign_calltools_id); ?>');"></i>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if( empty($permission_users) || in_array('7-6', $permission_users) ): ?>
                                                                <span style="cursor: pointer;" class="on-default remove-row" data-toggle="tooltip" data-placement="top" title="" data-original-title="Send Test Lead" data-trigger="hover" data-animation="false"
                                                                      onclick="return sendTestLeadForCamp('<?php echo e($campaign->campaign_id); ?>');">
                                                                    <i class="fa fa-share" ></i>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if( empty($permission_users) || in_array('7-1', $permission_users) ): ?>
                                                                <span style="cursor: pointer;color: #36c736;" class="on-default remove-row" data-toggle="tooltip" data-placement="top" title="" data-original-title="Add Clone" data-trigger="hover" data-animation="false">
                                                                    <i class="mdi mdi-plus-circle-outline" data-toggle="modal" data-target="#con-close-modal"
                                                                       onclick="return document.getElementById('campaign_id_menu').value = '<?php echo e($campaign->campaign_id); ?>';"></i>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if( empty($permission_users) || in_array('7-3', $permission_users) ): ?>
                                                                <form style="display: inline-block" action="<?php echo e(route('AdminCampaignDelete')); ?>" method="post" id="DeleteCampaignForm-<?php echo e($campaign->campaign_id); ?>">
                                                                    <?php echo e(csrf_field()); ?>

                                                                    <input type="hidden" class="form-control" value="<?php echo e($campaign->campaign_id); ?>" name="campaign_id">
                                                                </form>
                                                                <span style="cursor: pointer;" class="on-default remove-row" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" data-trigger="hover" data-animation="false"
                                                                      onclick="return DeleteCampaignForm('<?php echo e($campaign->campaign_id); ?>');">
                                                                    <i class="fa fa-trash-o"></i>
                                                                </span>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <a href="AdminCampaign/<?php echo e($campaign->campaign_id); ?>" class="on-default edit-row" data-toggle="tooltip" data-placement="top" title="" data-original-title="Details" data-trigger="hover" data-animation="false">
                                                                <i class="mdi mdi-file-document-box font-18 vertical-middle m-r-10"></i>
                                                            </a>
                                                            <a href="<?php echo e(route("Admin.Campaign.ZipCodes.List", $campaign->campaign_id)); ?>" class="on-default edit-row" data-toggle="tooltip" data-placement="top" title="" data-original-title="List OF ZipCodes" data-trigger="hover" data-animation="false">
                                                                <i class="fa fa-list"></i>
                                                            </a>
                                                            <?php if( empty($permission_users) || in_array('7-1', $permission_users) ): ?>
                                                                <span style="cursor: pointer;color: #36c736;" class="on-default remove-row" data-toggle="tooltip" data-placement="top" title="" data-original-title="Add Clone" data-trigger="hover" data-animation="false">
                                                                    <i class="mdi mdi-plus-circle-outline" data-toggle="modal" data-target="#con-close-modal"
                                                                       onclick="return document.getElementById('campaign_id_menu').value ='<?php echo e($campaign->campaign_id); ?>';"></i>
                                                                </span>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div id="con-close-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                         aria-hidden="true" style="display: none;">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                    <h4 class="modal-title">Add Campaign</h4>
                                </div>
                                <div class="modal-body row">
                                    <div class="col-sm-12">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <form action="<?php echo e(route('AdminCampaignAddClone')); ?>" method="post">
                                                    <?php echo e(csrf_field()); ?>

                                                    <div class="row">
                                                        <div class="col-sm-12">
                                                            <div class="form-group">
                                                                <label for="Campaign_name">Campaign Name<span class="requiredFields">*</span></label>
                                                                <input type="text" class="form-control" value="" name="campaign_name" required>
                                                                <input type="hidden" class="form-control" value="" id="campaign_id_menu" name="campaign_id" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-12">
                                                            <div class="form-group">
                                                                <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-primary waves-effect waves-light pull-right">Add</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal -->
                    <div class="modal" id="campaign_file_id" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Add CallTools Campaign Id</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="col-sm-12">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <form action="<?php echo e(route('AddCallToolsCampaignId')); ?>" method="post">
                                                    <?php echo e(csrf_field()); ?>

                                                    <div class="row">
                                                        <div class="col-sm-12">
                                                            <div class="form-group">
                                                                <label for="Campaign_name">CallTools Campaign Id<span class="requiredFields">*</span></label>
                                                                <input type="text" class="form-control" value="" id="campaign_file_idinputs" name="campaign_file_id" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="File_name">CallTools File Id<span class="requiredFields">*</span></label>
                                                                <input type="text" class="form-control" value="" id="campaign_file_idinputs_go" name="campaign_file_id_go" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <input type="hidden" class="form-control" value="" id="campaign_id_menu2" name="campaign_id" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-sm-12">
                                                            <div class="form-group">
                                                                <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-primary waves-effect waves-light pull-right">Add</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <script>
                        function openmenufunctioncampaign_file(campaign_id, file_calltools_id, campaign_calltools_id) {
                            document.getElementById('campaign_id_menu2').value = campaign_id;
                            document.getElementById('campaign_file_idinputs').value = file_calltools_id;
                            document.getElementById('campaign_file_idinputs_go').value = campaign_calltools_id;
                        }
                    </script>

                </div>
            </div>
        </div>
    </div>
    <!-- End Of Page 1-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\safadi\allieddigitalmediaNew\resources\views/Admin/Campaign/ListOfCampaign.blade.php ENDPATH**/ ?>