<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <meta content="<?php echo e(config('app.name', 'Laravel')); ?>" name="description"/>

    <?php echo $__env->make('include.include_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if( config('app.env', 'local') != "local" ): ?>
        <script src='https://www.google.com/recaptcha/api.js'></script>
        <script>
            function onSubmit(token) {
                document.getElementById("register-form").submit();
            }
        </script>
    <?php endif; ?>
</head>
<body>

<section class="formContainer1">
    <div class="formContainer">
        <div class="container">
            <form id="register-form" action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-sm-12 col-md-6 col-lg-6 px-0">
                        <div class="marginCont heightauto">
                            <div class="formCont text-center formBigScreen login-screen">
                                <img class="logo-img1" src="<?php echo e(asset('images/NewLogin/Group265.svg')); ?>">
                                <h2>Welcome Back!</h2>
                                <p class="helloP">Hello, in order to view your account details, please login using your username and password. For assistance, please <a href="mailto:info@allieddigitalmedia.com" class="clickH">Click Here!</a></p>
                                <div class="form-group row">
                                    <div class="col-12">
                                        <input class="form-control inputContTT emailLogin" type="email" name="email" id="emailaddress"
                                               required="" placeholder="Username"
                                               value="
                                        <?php if( old('email')  ): ?>
                                               <?php echo e(old('email')); ?>

                                               <?php else: ?>
                                               <?php echo e(Cookie::get('PetraEmail')); ?>

                                               <?php endif; ?>
                                                   ">
                                        <i class="fa fa-user user-icon"></i>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-12">
                                        <input class="form-control inputContTT passLogin" type="password" name="password"
                                               id="password" required="" placeholder="Password"
                                               value="<?php if(old('password')): ?><?php echo e(old('password')); ?><?php else: ?><?php echo e(Cookie::get('PetraPassword')); ?><?php endif; ?>">
                                        <i class="fa fa-lock pass-icon"></i>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-xs-12">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p class="errorText">
                                                <?php echo e($error); ?>

                                            </p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-6 text-left">
                                        <div class="checkbox checkbox-success">
                                            <input type="checkbox" type="checkbox" name="remember" id="remember" checked>
                                            <label class="passLabel" for="remember">
                                                <?php echo e(__('Remember Me')); ?>

                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <?php if(Route::has('password.request')): ?>
                                            <a href="<?php echo e(route('password.request')); ?>" class="pull-right forgotPLOg"><small>Forgot Password?</small></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-12">
                                        <button type="button" class="btn btn-block logInButton" onclick="document.getElementById('login-ADM-submit').click();">Login
                                        </button>
                                    </div>
                                    <div class="col-sm-12 text-center">
                                        <p class="noAccount">Don't have an account? <a href="<?php echo e(route('register')); ?>" class="signUpCo"><b>Create One!</b></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-6 px-0">
                        <div class="marginContRight heightauto">
                            <div class="formContRight">
                                <img class='logo-img' src="<?php echo e(asset('images/NewLogin/Group265.svg')); ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <button type="submit" class="btn btn-block g-recaptcha logInButton" form="register-form"
            data-sitekey="<?php echo e(config('services.RECAPTCHA.RECAPTCHA_SITE_KEY', '')); ?>"
            data-callback="onSubmit" id="login-ADM-submit" style="display: none;">
    </button>
</section>

<?php echo $__env->make('include.include_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>

<?php /**PATH C:\Users\admin\Desktop\safadi\allieddigitalmediaNew\resources\views/auth/Allied/loginAllied.blade.php ENDPATH**/ ?>