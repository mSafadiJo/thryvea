

<?php if(Config::get('app.name') == 'Zone1Remodeling'): ?>
    <?php echo $__env->make('auth.Zone.loginZone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('auth.Allied.loginAllied', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\admin\Desktop\safadi\allieddigitalmediaNew\resources\views/auth/login.blade.php ENDPATH**/ ?>