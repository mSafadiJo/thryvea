<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Styles -->
    <?php echo $__env->make('include.include_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

<!-- Begin page -->
<div id="wrapper">

    <!-- Top Bar Start -->
    <div class="topbar">

        <!-- LOGO -->
        <div class="topbar-left">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                

                <?php if(Config::get('app.name') == 'Zone1Remodeling'): ?>
                    <img src="<?php echo e(URL::asset('images/zone1iconblack.svg')); ?>" style="width: 45%;"/>
                <?php else: ?>
                    <img src="<?php echo e(URL::asset('images/Allied/Allieddigitalmedia_gray.png')); ?>" width="200px"/>
                <?php endif; ?>
            </a>
        </div>

        <nav class="navbar-custom">
            <ul class="list-inline menu-left mb-0">
                <a id="navbarDropdown" class="nav-link dropdown-toggle pull-right" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre style="color:inherit;">
                    <b><?php echo e(Auth::user()->username); ?></b> <i class="dripicons-chevron-down"></i>
                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('AdminProfile')); ?>">Profile Setting</a>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </ul>
        </nav>

    </div>
    <!-- Top Bar End -->


    <!-- ========== Left Sidebar Start ========== -->
    <div class="left side-menu">
        <div class="slimscroll-menu" id="remove-scroll">
        <?php
            $permission_users = array();
            if( !empty(Auth::user()->permission_users) ){
                $permission_users = json_decode(Auth::user()->permission_users, true);
            }
        ?>
        <!--- Sidemenu -->
            <div id="sidebar-menu">
                <!-- Left Menu Start -->
                <ul class="metismenu" id="side-menu">
                    <?php if( empty($permission_users) || in_array('25-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/setting.svg')); ?>">
                                <span> Settings </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <?php if( empty($permission_users) || in_array('25-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Setting.Payment')); ?>">Payment Methods</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('2-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/promocode.svg')); ?>">
                                <span> Promotional Codes </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(route('PromoCode.index')); ?>">List Of Promotional Codes</a></li>
                                <?php if( empty($permission_users) || in_array('2-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('PromoCode.create')); ?>">Add Promotional Codes</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('3-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/reports.jpeg')); ?>">
                                <span> Reports </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <?php if( empty($permission_users) || in_array('3-12', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Report.AccountManagerReport')); ?>">Account Manager Reports</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-14', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('FilterZipCodeByServiceShow')); ?>">Active ZipCodes</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-22', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('AffiliateReport')); ?>">Affiliate Report</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-23', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('AgentsCallCenter')); ?>">Agents CallCenter Report</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-27', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('BuyersLocationReport.index')); ?>">Buyers Location Report</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-18', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('mapBuyer')); ?>">Buyers Map</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-25', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Reports.callCenterProfit')); ?>">Call Center Profit Report</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-24', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.CallCenter.Dashboard')); ?>">CallCenter Target Dashboard</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-13', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('FilterCampaignByZipCodeAndService')); ?>">Campaigns By Zipcode</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-16', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('FilterCRMShow')); ?>">CRM Responses</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-17', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('map')); ?>">Lead Map</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-5', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Report.lead_report')); ?>">Lead Report</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-6', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Report.lead_volume')); ?>">Lead Volume</a></li>
                                <?php endif; ?>
                                
                                
                                
                                <?php if( empty($permission_users) || in_array('3-28', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('marketingCost')); ?>">Marketing Cost</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-8', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Report.lead_from_websites')); ?>">Marketing Reports</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-26', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('payPerClickReport')); ?>">PayPerClick Campaign Report</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-7', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Report.performance_reports')); ?>">Performance Reports</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-19', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Reports.salesCommission')); ?>">Sales Commission</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-11', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Report.SalesReport')); ?>">Sales Reports</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-20', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Sales.Dashboard')); ?>">Sales/Transfers Dashboard</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-10', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Report.SDRReport')); ?>">SDR Reports</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-9', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Reports.Seller_Lead_Volume')); ?>">Seller Lead Volume</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('3-21', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Reports.users_payments')); ?>">Users Payments</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('4-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/manager.svg')); ?>">
                                <span> Admins </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(route('AdminManagment.index')); ?>">List Of Admins</a></li>
                                <?php if( empty($permission_users) || in_array('4-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('AdminManagment.create')); ?>">Add Admins</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('17-0', $permission_users) ): ?>
                        <li>
                            <a href="<?php echo e(route('Admin.JoinAsAPro.List')); ?>">
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/team.svg')); ?>">
                                <span> Contractors </span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('14-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/team.svg')); ?>">
                                <span> Prospects </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(route('Prospects.index')); ?>">List Of Prospects</a></li>
                                <?php if( empty($permission_users) || in_array('14-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Prospects.create')); ?>">Add Prospects</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('5-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/team.svg')); ?>">
                                <span> Buyers </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(route('Admin_Buyers')); ?>">List Of Buyers</a></li>
                                <?php if( empty($permission_users) || in_array('5-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin_BuyersAdd')); ?>">Add Buyers</a></li>
                                <?php endif; ?>
                                <li><a href="<?php echo e(route('Old_Buyers')); ?>">List Of Old Buyers</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('23-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/team.svg')); ?>">
                                <span> Sellers </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(route('ListOfSeller')); ?>">List Of Sellers</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('7-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/speaker.svg')); ?>">
                                <span> Buyers Campaigns </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(route('Admin_Campaign')); ?>">List Of Campaigns</a></li>
                                <?php if( empty($permission_users) || in_array('7-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Campaign.Create')); ?>">Add Campaigns</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if( empty($permission_users) || in_array('12-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/speaker.svg')); ?>">
                                <span> Sellers Campaigns </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(route('Campaigns.index')); ?>">List Of Campaigns</a></li>
                                <?php if( empty($permission_users) || in_array('12-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Campaigns.create')); ?>">Add Campaigns</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('6-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/account_ownership.jpeg')); ?>">
                                <span> Account ownership </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <?php if( empty($permission_users) || in_array('6-5', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Claim.index')); ?>">Claim</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('6-6', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.AccountOwnerShip.Payment')); ?>">Payment Term</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    
                    <?php if( empty($permission_users) || in_array('11-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/marketing.svg')); ?>">
                                <span>Shop Leads Info</span>
                                <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <?php if( empty($permission_users) || in_array('11-5', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('ShopLeads')); ?>">Sources Percentage</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('11-6', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('ExcludeAndIncludeSellers')); ?>">Include/Exclude Sellers</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('11-7', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('ExcludeBuyers')); ?>">Exclude Buyers</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('11-8', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('ExcludeSources')); ?>">Exclude Sources</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('11-9', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('ExcludeUrl')); ?>">Exclude Url</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('11-10', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('ExcludeSellerSources')); ?>">Exclude Seller Sources</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    

                    <?php if( empty($permission_users) || in_array('8-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/process.svg')); ?>">
                                <span> Leads Management </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <?php if( empty($permission_users) || in_array('8-12', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('list_of_leads_all')); ?>">List Of All Leads</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('8-5', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('list_of_leads_received')); ?>">List Of Sold Leads</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('8-6', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('list_of_leads_lost')); ?>">List Of UnSold Leads</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('8-14', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.list_of_leads_PINGs')); ?>">List Of PING Leads</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('8-16', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.list_of_leads_Affiliate')); ?>">List Of Affiliate Leads</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('8-7', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('list_of_leads_Refund')); ?>">List Of Return Leads</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('8-9', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('list_of_leads_Archive')); ?>">List Of Archive Leads</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('8-13', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('list_of_leads_Review')); ?>">List Of Leads Review</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('8-15', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('list_of_leads_SMS_Email')); ?>">List Of Leads</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('8-17', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('listOfLeadForm')); ?>">List Of Leads Form</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('8-18', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('list_of_leads_receivedCallCenter')); ?>">List Of Leads Call Center</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('8-19', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('list_of_leads_CallCenterReturns')); ?>">List Of Return Leads Call Center</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('8-20', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('list_of_CallLead')); ?>">List Of Call Leads</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('13-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/marketing.svg')); ?>">
                                <span> TS Marketing </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <?php if( empty($permission_users) || in_array('13-5', $permission_users) ): ?>
                                    <li>
                                        <a href="javascript: void(0);">
                                            <span> Platforms </span> <span class="menu-arrow" ></span>
                                        </a>
                                        <ul class="nav-third-level" aria-expanded="false">
                                            <li><a href="<?php echo e(route('Platforms.index')); ?>">List Of Platforms</a></li>
                                            <?php if( empty($permission_users) || in_array('13-1', $permission_users) ): ?>
                                                <li><a href="<?php echo e(route('Platforms.create')); ?>">Add Platforms</a></li>
                                            <?php endif; ?>
                                        </ul>
                                    </li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('13-6', $permission_users) ): ?>
                                    <li>
                                        <a href="javascript: void(0);">
                                            <span> Traffic Sources </span> <span class="menu-arrow"></span>
                                        </a>
                                        <ul class="nav-third-level" aria-expanded="false">
                                            <li><a href="<?php echo e(route('TrafficSources.index')); ?>">List Of TS</a></li>
                                            <?php if( empty($permission_users) || in_array('13-1', $permission_users) ): ?>
                                                <li><a href="<?php echo e(route('TrafficSources.create')); ?>">Add TS</a></li>
                                            <?php endif; ?>
                                            <?php if( empty($permission_users) || in_array('13-8', $permission_users) ): ?>
                                                <li><a href="<?php echo e(route('tsLeadCost')); ?>">Lead Cost By TS</a></li>
                                            <?php endif; ?>
                                        </ul>
                                    </li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('13-7', $permission_users) ): ?>
                                    <li>
                                        <a href="javascript: void(0);">
                                            <span> Call Center Sources </span> <span class="menu-arrow"></span>
                                        </a>
                                        <ul class="nav-third-level" aria-expanded="false">
                                            <li><a href="<?php echo e(route('CallCenterSources.index')); ?>">List Of Call Center Sources</a></li>
                                            <?php if( empty($permission_users) || in_array('13-1', $permission_users) ): ?>
                                                <li><a href="<?php echo e(route('CallCenterSources.create')); ?>">Add Call Center Sources</a></li>
                                            <?php endif; ?>
                                        </ul>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('15-0', $permission_users) ): ?>
                        <li>
                            <a href="<?php echo e(route('Admin.BlockLeadsInfo')); ?>">
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/block.svg')); ?>">
                                <span> Block Leads Info </span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('16-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/speech-bubble.svg')); ?>">
                                <span> Send SMS </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <?php if( empty($permission_users) || in_array('16-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Marketing.SendSMS')); ?>">General SMS</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('16-2', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Marketing.SendProSMS')); ?>">Professional SMS</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('16-3', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('Admin.Marketing.GenerateURL')); ?>">Generate Bitly URL</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    <?php if( empty($permission_users) || in_array('1-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/support.svg')); ?>">
                                <span> Services </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(route('SuberAdminServices')); ?>">List Of Services</a></li>
                                <?php if( empty($permission_users) || in_array('1-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('AdminServicesAddForm')); ?>">Add Services</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('19-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                <i class="fa fa-picture-o" aria-hidden="true"></i>
                                <span> Themes </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(route('AllThemes')); ?>">List Of Themes</a></li>
                                <?php if( empty($permission_users) || in_array('19-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('ThemeAddForm')); ?>">Add Theme</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('20-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                <i class="icon-list"></i>
                                <span> Domian </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(route('AllDomains')); ?>">List Of Domains</a></li>
                                <?php if( empty($permission_users) || in_array('20-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('DomainAddForm')); ?>">Add Domains</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('21-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                <i class="fa fa-bar-chart" aria-hidden="true"></i>
                                <span> Pixels </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(route('pixels')); ?>">List Of Pixels</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('24-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                <i class="icon-list"></i>
                                <span> Our Partners </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(route('OurPartners.index')); ?>">List Of Partners</a></li>
                                <?php if( empty($permission_users) || in_array('24-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('OurPartners.create')); ?>">Add Partners</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('22-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/support.svg')); ?>">
                                <span> Tickets </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <?php if( empty($permission_users) || in_array('22-1', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('ShowIssueTicket')); ?>">Issue Tickets</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('22-2', $permission_users) ): ?>
                                    <li><a href="<?php echo e(route('ShowReturnTicket')); ?>">Return Tickets</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if( empty($permission_users) || in_array('10-0', $permission_users) ): ?>
                        <li>
                            <a href="javascript: void(0);">
                                
                                <img class="menuLogo_svg" src="<?php echo e(URL::asset('images/menuLogo/svg/remote-access.svg')); ?>">
                                <span> Access Log </span> <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <?php if( empty($permission_users) || in_array('10-5', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/Services/AccessLog')); ?>">Services</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-20', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/ThemeTemplates/AccessLog')); ?>">Themes</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-21', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/DomainTemplates/AccessLog')); ?>">Domains</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-6', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/PromoCode/AccessLog')); ?>">Promo Codes</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-7', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/Admin/AccessLog')); ?>">Admin User</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-17', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/ProspectUsers/AccessLog')); ?>">Prospect User</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-8', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/Buyers/AccessLog')); ?>">Buyers User</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-9', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/Campaign/AccessLog')); ?>">Buyer Campaigns</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-14', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/SellerCampaign/AccessLog')); ?>">Seller Campaigns</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-10', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/LeadManagement/AccessLog')); ?>">Lead Management</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-11', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/Authentication/AccessLog')); ?>">Authentication</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-12', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/Ticket/AccessLog')); ?>">Ticket</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-13', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/Payment/AccessLog')); ?>">User Payments</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-15', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/MarketingPlatform/AccessLog')); ?>">Marketing Platforms</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-16', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/MarketingTrafficSources/AccessLog')); ?>">Marketing TS</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-18', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/BlockLead/AccessLog')); ?>">Block Leads Info</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-19', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/SendSMS/AccessLog')); ?>">Send SMS</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-22', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/ShopLeads/AccessLog')); ?>">Shop Leads</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-23', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/CallCenterSource/AccessLog')); ?>">Call Center Sources</a></li>
                                <?php endif; ?>
                                <?php if( empty($permission_users) || in_array('10-24', $permission_users) ): ?>
                                    <li><a href="<?php echo e(url('/Admin/LeadCostByTS/AccessLog')); ?>">Lead Cost By TS</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                </ul>
            </div>
            <!-- Sidebar -->
            <div class="clearfix"></div>

        </div>
        <!-- Sidebar -left -->

    </div>
    <!-- Left Sidebar End -->

    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <?php echo $__env->make('include.include_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-page">
        <!-- Start content -->
        <div class="content">
            <div class="container-fluid">

                <?php echo $__env->yieldContent('content'); ?>

            </div> <!-- container -->

        </div> <!-- content -->

    </div>
    <!-- ============================================================== -->
    <!-- End Right content here -->
    <!-- ============================================================== -->
</div>

</body>
</html>
<?php /**PATH C:\Users\admin\Desktop\safadi\allieddigitalmediaNew\resources\views/layouts/adminapp.blade.php ENDPATH**/ ?>