<script>
    var resizefunc = [];

    var urlstates = "<?php echo e(route('GetStates')); ?>";
    var urlstatesAll = "<?php echo e(route('GetStatesAll')); ?>";
    var urlstatesSelected = "<?php echo e(route('GetStatesSelected')); ?>";
    var urlcities = "<?php echo e(route('GetCities')); ?>";
    var urlcitiesALL = "<?php echo e(route('GetCitiesALL')); ?>";
    var urlCountiesALL = "<?php echo e(route('getCountiesALL')); ?>";
    var urlcitiesSelected = "<?php echo e(route('GetCitiesSelected')); ?>";
    var urlzipCodes = "<?php echo e(route('getZipCodes')); ?>";
    var getAllZipCodeReview = "<?php echo e(route('getAllZipCodeReview')); ?>";
    var urlzipCodesAll = "<?php echo e(route('getZipCodesAll')); ?>";
    var urlzipCodesSelected = "<?php echo e(route('getZipCodesSelected')); ?>";
    var CampaignChangeStatus = "<?php echo e(route('CampaignChangeStatus')); ?>";
    var AdminCampaignChangeStatus = "<?php echo e(route('AdminCampaignChangeStatus')); ?>";
    var getCountieswithFillter = "<?php echo e(route('getCountieswithFillter')); ?>";
    var getAllCounties = "<?php echo e(route('getAllCounties')); ?>";
    var getAllWhithFillter = "<?php echo e(route('getAllWhithFillter')); ?>";
    var getAllWhithFillterZipCode = "<?php echo e(route('getAllWhithFillterZipCode')); ?>";
    var AddTransactionPayPal = "<?php echo e(route('AddTransactionPayPal')); ?>";
    var TransactionValueStore = "<?php echo e(route('Transaction.Value.Store')); ?>";
    var GetPaymentDetailsAjax = "<?php echo e(route('GetPaymentDetailsAjax')); ?>";
    var TransactionvalueinPayPalButtons = "<?php echo e(route('TransactionvalueinPayPalButtons')); ?>";
    var TicketChangeStatus = "<?php echo e(route('TicketChangeStatus')); ?>";
    var adminClaimChangeStatus = "<?php echo e(route('Admin.Claim.Edit_Status')); ?>";
    var adminAccountOwnerShipChangeStatus = "<?php echo e(route('Admin.AccountOwnerShip.Payment.Edit')); ?>";
    var getCityReview = "<?php echo e(route('getCityReview')); ?>";

    //Reports URL
    var AdminReportlead_volumedata = "<?php echo e(route('Admin.Report.lead_volume.data')); ?>";
    var AdminReportPerformance_Reportsdata = "<?php echo e(route('Admin.Report.Performance_Reports.data')); ?>";
    var AdminReportlead_from_websitesdata = "<?php echo e(route('Admin.Report.lead_from_websites.data')); ?>";
    var AdminReportlead_reportdata = "<?php echo e(route('Admin.Report.lead_report.data')); ?>";

    //Filters URL
    var AdminCampaignStorFilter = "<?php echo e(route('AdminCampaignStor.Filter')); ?>";
    var list_of_leads_SMS_Email_ajax = "<?php echo e(route('list_of_leads_SMS_Email_ajax')); ?>";
    var UpdateStatusServicedSuperAdmin = "<?php echo e(route('UpdateStatusServicedSuperAdmin')); ?>";

    var ExportlistZipCodeByService = "<?php echo e(route('ExportlistZipCodeByService')); ?>";
    var ExportlistZipCodeByService = "<?php echo e(route('ExportlistZipCodeByService')); ?>";

    //new var for buyer and seller page
    var list_of_leads_BuyersAjax = "<?php echo e(route('list_of_leads_BuyersAjax')); ?>";
    var list_of_leads_SellerAjax = "<?php echo e(route('list_of_leads_Seller')); ?>";
    var BuyersListOfClickLeadsAjax = "<?php echo e(route('Buyers.ListOfClickLeads.Ajax')); ?>";
    var ReturnLeadBuyerAjax = "<?php echo e(route('ReturnLeadBuyerAjax')); ?>";

    //filiter Zipcde
    var FilterLostLeadReportAjax = "<?php echo e(route('FilterLostLeadReportAjax')); ?>";

    //new ticket
    var ShowReturnTicketAjax = "<?php echo e(route('ShowReturnTicketAjax')); ?>";

    var ShowIssueTicketAjax = "<?php echo e(route('ShowIssueTicketAjax')); ?>";

    
    
    var AdminCampaigndeleteAllCounty = "<?php echo e(route('Admin.Campaign.deleteAllCounty')); ?>";
    var AdminCampaigndeleteAllCity = "<?php echo e(route('Admin.Campaign.deleteAllCity')); ?>";
    var AdminCampaigndeleteAllZipcode = "<?php echo e(route('Admin.Campaign.deleteAllZipcode')); ?>";
    var AdminCampaigndeleteAllCountyExpect = "<?php echo e(route('Admin.Campaign.deleteAllCountyExpect')); ?>";
    var AdminCampaigndeleteAllCityExpect = "<?php echo e(route('Admin.Campaign.deleteAllCityExpect')); ?>";
    var AdminCampaigndeleteAllZipcodeExpect = "<?php echo e(route('Admin.Campaign.deleteAllZipcodeExpect')); ?>";

    var AdminCampaignsendTestLead = "<?php echo e(route('Admin.Campaign.sendTestLead')); ?>";
    var AdminSellerCampaignsfilter = "<?php echo e(route('Admin.Seller.Campaigns.filter')); ?>";
    var AdminReportsSeller_Lead_VolumeSearch = "<?php echo e(route('Admin.Reports.Seller_Lead_Volume.Search')); ?>";
    var AdminReportSalesReportdata = "<?php echo e(route('Admin.Report.SalesReport.data')); ?>";
    var AdminReportSDRReportdata = "<?php echo e(route('Admin.Report.SDRReport.data')); ?>";
    var AdminReportAccountManagerReportdata = "<?php echo e(route('Admin.Report.AccountManagerReport.data')); ?>";
    var updateStatusThemesUserAdmin = "<?php echo e(route('updateStatusThemesUserAdmin')); ?>";
    var updateStatusDomainsUserAdmin = "<?php echo e(route('updateStatusDomainsUserAdmin')); ?>";

    var accessLogSearchGeneral = "<?php echo e(route('AccessLog.search')); ?>";

    //Block Lead Info
    var block_lead_info_ajax = "<?php echo e(route('Admin.BlockLeadsInfo.logic_data')); ?>";

    //Change Lead Status on buyer dashboard
    var buyerLeadChangeStatus = "<?php echo e(route('buyer.LeadChangeStatus')); ?>";

    //Send Test Lead
    var adminCampaign_sendTestLead = "<?php echo e(route('AdminCampaign.sendTestLead')); ?>";

    ///get all trific soruce
    var getAllTrafficSorce = "<?php echo e(route('getAllTrafficSorce')); ?>";
    var trafficSourceAjax = "<?php echo e(route('trafficSourceAjax')); ?>";
    var ListImageThemes = "<?php echo e(route('ListImageThemes')); ?>";

    
    
    
    
    
    
    
    
    
    
    
    

    var export_lead_data = "<?php echo e(route('export_lead_data')); ?>";

    var AdminProspectsSearch = "<?php echo e(route('Admin.Prospects.Search')); ?>";

    var token = "<?php echo e(Session::token()); ?>"

    var citysearch = "<?php echo e(route('cityResult')); ?>";
    var countysearch = "<?php echo e(route('countyResult')); ?>";
    var zipsearch = "<?php echo e(route('zipResult')); ?>";
    var ReportsSalesCommissionSearch = "<?php echo e(route('Reports.salesCommission.Search')); ?>";

    //For Shop Leads
    var getCampaignsByBuyer = "<?php echo e(route('ShopLeadsCampaigns')); ?>";
    var getCampaignsByBuyerEx = "<?php echo e(route('ShopLeadsCampaignsEx')); ?>";

    var getAllSourceByCampaign = "<?php echo e(route('ShopLeadsSource')); ?>";

    //Sales Dashboard
    var AdminSalesStoreSetting = "<?php echo e(route('Admin.Sales.StoreSetting')); ?>";
    var AdminSalesStoreTransfers = "<?php echo e(route('Admin.Sales.StoreTransfers')); ?>";
    var SalesDashboardReload = "<?php echo e(route('Sales.Dashboard.Reload')); ?>";
    var CallCenterDashboardReload = "<?php echo e(route('CallCenter.Dashboard.Reload')); ?>";

    //Lead Form
    var list_of_leads_FormAjax = "<?php echo e(route('list_of_leads_FormAjax')); ?>";

    //Call Leads
    var list_of_CallLead_ajax = "<?php echo e(route('list_of_CallLead_ajax')); ?>";

    //report
    var AffiliateReportAjax = "<?php echo e(route('AffiliateReportAjax')); ?>";
    var AgentsCallCenterAjax = "<?php echo e(route('AgentsCallCenterAjax')); ?>";
    var ReportscallCenterProfitSearch = "<?php echo e(route('Reports.callCenterProfit.Search')); ?>";
    var QAChangeStatusLead = "<?php echo e(route('QAChangeStatusLead')); ?>";
    var MarketingCostReport = "<?php echo e(route('marketingCostData')); ?>";
    var buyer_lead_note_update = "<?php echo e(route('buyer_lead_note_update')); ?>";

    //Lead RevShareSeller
    var HomeRevShareSellerAjax = "<?php echo e(route('HomeRevShareSellerAjax')); ?>";
    var list_of_LeadsRevShareAjax = "<?php echo e(route('list_of_LeadsRevShareAjax')); ?>";
    //Delete ACH Payments
    var Delete_ACH_Credit = "<?php echo e(route('DeleteACHCredit')); ?>";
</script>

<!-- jQuery  -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/tether.min.js')); ?>"></script><!-- Tether for Bootstrap -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/waves.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(asset('js/modernizr.min.js')); ?>"></script>

<!-- App js -->
<script src="<?php echo e(asset('js/jquery.core.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.app.js')); ?>"></script>
<!-- themes js -->
<script src="<?php echo e(asset('js/themes/theme.js')); ?>"></script>
<!-- domains js -->
<script src="<?php echo e(asset('js/domains/domain.js')); ?>"></script>

<script src="<?php echo e(asset('plugins/jquery-validation/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/vfs_fonts.js')); ?>"></script>

<script src="<?php echo e(asset('plugins/datatables/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>

<script src="<?php echo e(asset('ajax/allAjaxPages.js')); ?>"></script>
<script src="<?php echo e(asset('js/AllJs.js')); ?>"></script>
<script src="<?php echo e(asset('js/newLogIn.js')); ?>"></script>
<script src="<?php echo e(asset('js/campaign_services.js')); ?>"></script>
<script src="<?php echo e(asset('js/formsjs.js')); ?>"></script>

<!-- map files -->
<script src="<?php echo e(asset('js/raphael.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.usmap.js')); ?>"></script>
<script src="<?php echo e(asset('js/map.js')); ?>"></script>
<script src="<?php echo e(asset('js/ShopLead/ShopLead.js')); ?>"></script>

<!-- campaign  City And Zipcode Filter files -->
<script src="<?php echo e(asset('js/campaignCityAndZipcodeFilter.js')); ?>"></script>

<script src="<?php echo e(asset('js/jquery.creditCardValidator.js')); ?>"></script>
<script src="<?php echo e(asset('js/credit-card-js.js')); ?>"></script>
<script src="<?php echo e(asset('js/timeslotCampaign.js')); ?>"></script>

<script src="<?php echo e(asset('ajax/reports.js')); ?>"></script>
<script src="<?php echo e(asset('ajax/fillterAdmin.js')); ?>"></script>
<script src="<?php echo e(asset('js/dillerProject.js')); ?>"></script>

<!--Form Wizard-->
<?php if( Request::is("register") ): ?>
    <script src="<?php echo e(asset('plugins/jquery.stepy.regestration/jquery.stepy.js')); ?>" type="text/javascript"></script>
<?php else: ?>
    <script src="<?php echo e(asset('plugins/jquery.stepy/jquery.stepy.js')); ?>" type="text/javascript"></script>
<?php endif; ?>

<!--wizard initialization-->
<script src="<?php echo e(asset('pages/jquery.wizard-init.js')); ?>" type="text/javascript"></script>

<!-- plugin js -->
<script src="<?php echo e(asset('plugins/moment/moment.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/clockpicker/js/bootstrap-clockpicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>

<!-- select 2-->
<script src="//cdnjs.cloudflare.com/ajax/libs/lodash.js/4.15.0/lodash.min.js"></script>
<script src="<?php echo e(asset('plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>


<?php if( !(Request::is("BuyersPayPayment") || Route::is("Transaction.Value.Create") || Route::is('Transaction.Value.StoreOther')
     || Route::is('AddValuePayment') || Route::is('Admin.Buyers.payments') || Route::is('Transaction.Value.Create.Admin')
     || Route::is('Transaction.Value.StoreOtherAdmin')) ): ?>

    <script src="<?php echo e(asset('plugins/bootstrap-tagsinput/js/bootstrap-tagsinput.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('pages/jquery.form-advanced.init.js')); ?>" type="text/javascript"></script>
<?php endif; ?>

<script src="<?php echo e(asset('plugins/magnific-popup/js/jquery.magnific-popup.min.js')); ?>" type="text/javascript"></script>


<script src="<?php echo e(asset('pages/jquery.form-pickers.init.js')); ?>"></script>

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">

<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>


<script src="<?php echo e(asset('js/bootstrap-datetimepicker.min.js')); ?>"></script>

<?php if( Route::is("Sales.Dashboard") ): ?>
    <script src="<?php echo e(asset('js/SalesDashboard/dashboard.js')); ?>"></script>
<?php endif; ?>
<?php if( Route::is("CallCenter.Dashboard") ): ?>
    <script src="<?php echo e(asset('js/SalesDashboard/callCenterDashboard.js')); ?>"></script>
<?php endif; ?>
<?php /**PATH C:\Users\admin\Desktop\safadi\allieddigitalmediaNew\resources\views/include/include_js.blade.php ENDPATH**/ ?>