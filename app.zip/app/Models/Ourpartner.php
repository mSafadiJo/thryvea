<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ourpartner extends Model
{
    protected $fillable = ['partner'];
}
