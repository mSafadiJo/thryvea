<?php

namespace App\Http\Controllers;

use App\AccessLog;
use App\State;
use App\User;
use App\Zip_code;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class SuperAdminConrollAdmin extends Controller
{
    public function __construct(Request $request)
    {
        $request->permission_page = '4-0';
        $this->middleware(['auth', 'AdminMiddleware', 'PermissionUsers']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $col_name = null;
        $query = null;
        $sort_search = null;
        $sort_type = null;

        $admins = DB::table('users')
            ->join('zip_codes', 'zip_codes.zip_code_id', '=', 'users.zip_code_id')
            ->join('zip_codes_lists', 'zip_codes_lists.zip_code_list_id', '=', 'zip_codes.zip_code')
            ->join('cities', 'cities.city_id', '=', 'zip_codes.city_id')
            ->whereIn('users.role_id', [1, 2]);

        if ($request->type != null){
            $var = explode(",", $request->type);
            $col_name = $var[0];
            $query = $var[1];
            $admins = $admins->orderBy($col_name, $query);
            $sort_type = $request->type;
        }
        if ($request->search != null){
            $sort_search = $request->search;
            $admins = $admins->where(function ($query) use($sort_search) {
                $query->where('users.username', 'like', '%'.$sort_search.'%');
                $query->OrWhere('users.user_business_name', 'like', '%'.$sort_search.'%');
            });
            $sort_search = $request->search;
        }

        $admins = $admins->orderBy('users.created_at', 'desc')
            ->select([
                'users.username', 'users.email', 'users.user_business_name', 'users.user_phone_number', 'users.user_owner',
                'users.user_mobile_number', 'users.created_at', 'cities.city_name', 'zip_codes_lists.zip_code_list', 'users.id',
                'users.user_visibility', 'users.role_id', 'users.account_type'
            ]);

//        $admins = $admins->paginate(15);
        $admins = $admins->get();

        return view('SuperAdmin.Admin.index', compact('admins', 'col_name', 'query', 'sort_search', 'sort_type'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $states = State::All();
        return view('SuperAdmin.Admin.AddadminForm')->with('states', $states);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'firstname' => ['required', 'string', 'max:255'],
            'lastname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'owner' => ['required', 'string', 'max:255'],
            'businessname' => ['required', 'string', 'max:255'],
            'phonenumber' => ['required', 'string', 'max:255'],
            'mobilenumber' => ['required', 'string', 'max:255'],
            'state' => ['required', 'string', 'max:255'],
            'zipcode' => ['required', 'string', 'max:255'],
            'city' => ['required', 'string', 'max:255'],
            'streetname' => ['required', 'string', 'max:255'],
            'user_account_type' => ['required', 'string', 'max:255'],
            'user_privileges'
        ]);

        //Save ZipCode
        $zip_code = new Zip_code();
        $zip_code->city_id = $request['city'];
        $zip_code->zip_code = $request['zipcode'];
        $zip_code->street_name = $request['streetname'];
        $zip_code->state_id = $request['state'];
        $zip_code->save();
        $zip_code_id = DB::getPdo()->lastInsertId();

        $user_privileges = "";
        if( !empty($request['user_privileges'])) {
            $user_privileges = json_encode($request['user_privileges']);
        }

        if( $request['verify'] !== null ){
            User::create([
                'user_first_name' => $request['firstname'],
                'user_last_name' => $request['lastname'],
                'username' => ucwords($request['firstname'] . " " . $request['lastname']),
                'email' => $request['email'],
                'password' => Hash::make($request['password']),
                'user_owner' => $request['owner'],
                'zip_code_id' => $zip_code_id,
                'user_business_name' => $request['businessname'],
                'user_phone_number' => $request['phonenumber'],
                'user_mobile_number' => $request['mobilenumber'],
                'role_id' => 2,
                'user_type' => 2,
                'account_type' => $request['user_account_type'],
                'num_of_login' => 1,
                'last_login' =>  date('Y-m-d H:i:s'),
                'permission_users' => $user_privileges,
                'email_verified_at' =>  date('Y-m-d H:i:s')
            ]);

            $user_id = DB::getPdo()->lastInsertId();
        }
        else {
            User::create([
                'user_first_name' => $request['firstname'],
                'user_last_name' => $request['lastname'],
                'username' => ucwords($request['firstname'] . " " . $request['lastname']),
                'email' => $request['email'],
                'password' => Hash::make($request['password']),
                'user_owner' => $request['owner'],
                'zip_code_id' => $zip_code_id,
                'user_business_name' => $request['businessname'],
                'user_phone_number' => $request['phonenumber'],
                'user_mobile_number' => $request['mobilenumber'],
                'role_id' => 2,
                'user_type' => 2,
                'account_type' => $request['user_account_type'],
                'num_of_login' => 1,
                'last_login' =>  date('Y-m-d H:i:s'),
                'permission_users' => $user_privileges
            ]);

            $user_id = DB::getPdo()->lastInsertId();
            $currentuser = User::find($user_id);
            $currentuser->sendEmailVerificationNotification();
        }

        AccessLog::create([
            'user_id' => Auth::user()->id,
            'user_name' => Auth::user()->username,
            'section_id' => $user_id,
            'section_name' => ucwords($request['firstname'] . " " . $request['lastname']),
            'user_role' => Auth::user()->role_id,
            'section'   => 'Admin',
            'action'    => 'Created',
            'ip_address' => request()->ip(),
            'location' => json_encode(\Location::get(request()->ip())),
            'request_method' => json_encode($request->all())
        ]);

        return redirect('AdminManagment');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $states = State::All();
        $user_data = User::find($id);

        $zip_code_id = $user_data->zip_code_id;
        $zip_codes = DB::table('zip_codes')->where('zip_code_id', $zip_code_id)->get();

        $zip_code = $street = $city_id = '';
        foreach( $zip_codes as $item ){
            $zip_code = $item->zip_code;
            $street = $item->street_name;
            $city_id = $item->city_id;
        }

        $state_id = DB::table('cities')->where('city_id', $city_id) ->first('state_id');

        $listOfIds = array(
            'state_id'      => $state_id->state_id,
            'city_id'       => $city_id,
            'zip_code'      => $zip_code,
            'street'        => $street
        );

        return view('SuperAdmin.Admin.edit')
            ->with('states', $states)
            ->with('user_data', $user_data)
            ->with('listOfIds', $listOfIds)
            ->with('errormsg', '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'firstname' => 'required|string',
            'lastname' => 'required|string',
            'email' => 'required|email',
            'owner' => 'required|string',
            'businessname' => 'required|string',
            'phonenumber' => 'required',
            'mobilenumber' => 'required',
            'state' => 'required',
            'city'=> 'required',
            'zipcode' => 'required',
            'streetname'=> 'required',
            'zip_code_id' => 'required',
            'user_account_type' => 'required',
            'user_privileges'
        ]);

        $user_privileges = "";
        if( !empty($request['user_privileges'])) {
            $user_privileges = json_encode($request['user_privileges']);
        }

        $user_details =   DB::table('users')->where('id', $id)->first();

        $imagename1 = $user_details->adminIcon1;
        if ($request->hasFile('adminIcon1')) {
            $image1 = $request->file('adminIcon1');
            $imagename1 = time().'-1.'.$image1->getClientOriginalExtension();
            $destinationPath1 = public_path('/images/salesDashboard');
            $image1->move($destinationPath1, $imagename1);
        }

        $imagename2 = $user_details->adminIcon2;
        if ($request->hasFile('adminIcon2')) {
            $image2 = $request->file('adminIcon2');
            $imagename2 = time().'-2.'.$image2->getClientOriginalExtension();
            $destinationPath2 = public_path('/images/salesDashboard');
            $image2->move($destinationPath2, $imagename2);
        }

        $imagename3 = $user_details->adminIcon3;
        if ($request->hasFile('adminIcon3')) {
            $image3 = $request->file('adminIcon3');
            $imagename3 = time().'-3.'.$image3->getClientOriginalExtension();
            $destinationPath3 = public_path('/images/salesDashboard');
            $image3->move($destinationPath3, $imagename3);
        }

        DB::table('zip_codes')
            ->where('zip_code_id', $request['zip_code_id'] )
            ->update([
                'zip_code' => $request['zipcode'],
                'street_name' => $request['streetname'],
                'city_id' => $request['city'],
                'state_id' => $request['state']
            ]);

        DB::table('users')
            ->where('id', $id)
            ->update([
                'user_first_name' => $request['firstname'],
                'user_last_name' => $request['lastname'],
                'username' => ucwords($request['firstname'] . ' ' .$request['lastname']),
                'email' => $request['email'],
                'user_owner' => $request['owner'],
                'user_business_name' => $request['businessname'],
                'user_phone_number' => $request['phonenumber'],
                'user_mobile_number' => $request['mobilenumber'],
                'role_id' => $request['user_role'],
                'user_type' => $request['user_role'],
                'account_type' => $request['user_account_type'],
                'permission_users' => $user_privileges,
                'adminIcon1' => $imagename1,
                'adminIcon2' => $imagename2,
                'adminIcon3' => $imagename3
            ]);

        AccessLog::create([
            'user_id' => Auth::user()->id,
            'user_name' => Auth::user()->username,
            'section_id' => $id,
            'section_name' => ucwords($request['firstname'] . ' ' .$request['lastname']),
            'user_role' => Auth::user()->role_id,
            'section'   => 'Admin',
            'action'    => 'Updated',
            'ip_address' => request()->ip(),
            'location' => json_encode(\Location::get(request()->ip())),
            'request_method' => json_encode($request->all())
        ]);

        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::table('users')->where('id', $id)
            ->update(['user_visibility'=>0]);


        $username = DB::table('users')->where('id', $id)->first('username');
        AccessLog::create([
            'user_id' => Auth::user()->id,
            'user_name' => Auth::user()->username,
            'section_id' => $id,
            'section_name' => $username->username,
            'user_role' => Auth::user()->role_id,
            'section'   => 'Admin',
            'action'    => 'Deleted',
            'ip_address' => request()->ip(),
            'location' => json_encode(\Location::get(request()->ip())),
            'request_method' => ''
        ]);

        return redirect()->back();
    }
}
