<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Zip_code extends Model
{
    public function city(){
        return $this->belongsTo('App\City');
    }

    public function zipCodesList(){
        return $this->belongsTo('App\ZipCodesList');
    }

    public function users(){
        return $this->hasMany('App\User');
    }

    protected $fillable = [
        'city_id', 'zip_code', 'zip_code_description', 'street_name', 'state_id'
    ];
}
