INSERT INTO `handyman_childproofing_services` (`handyman_childproofing_services_id`, `handyman_childproofing_services_type`) VALUES (1, 'Purchasing of products only');
INSERT INTO `handyman_childproofing_services` (`handyman_childproofing_services_id`, `handyman_childproofing_services_type`) VALUES (2, 'Installation of products only');
INSERT INTO `handyman_childproofing_services` (`handyman_childproofing_services_id`, `handyman_childproofing_services_type`) VALUES (3, 'Both purchase and installation of products');
