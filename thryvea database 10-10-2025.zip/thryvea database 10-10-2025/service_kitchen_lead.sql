INSERT INTO `service_kitchen_lead` (`service_kitchen_lead_id`, `service_kitchen_lead_type`) VALUES (1, 'Full Kitchen Remodeling');
INSERT INTO `service_kitchen_lead` (`service_kitchen_lead_id`, `service_kitchen_lead_type`) VALUES (2, 'Cabinet Refacing');
INSERT INTO `service_kitchen_lead` (`service_kitchen_lead_id`, `service_kitchen_lead_type`) VALUES (3, 'Cabinet Install');
