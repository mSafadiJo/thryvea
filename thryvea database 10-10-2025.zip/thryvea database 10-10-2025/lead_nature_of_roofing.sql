INSERT INTO `lead_nature_of_roofing` (`lead_nature_of_roofing_id`, `lead_nature_of_roofing_name`) VALUES (1, 'Install roof on new construction');
INSERT INTO `lead_nature_of_roofing` (`lead_nature_of_roofing_id`, `lead_nature_of_roofing_name`) VALUES (2, 'Completely replace roof');
INSERT INTO `lead_nature_of_roofing` (`lead_nature_of_roofing_id`, `lead_nature_of_roofing_name`) VALUES (3, 'Repair existing roof');
