INSERT INTO `handyman_doors_windows_many` (`handyman_doors_windows_many_id`, `handyman_doors_windows_many_type`) VALUES (1, '1-2');
INSERT INTO `handyman_doors_windows_many` (`handyman_doors_windows_many_id`, `handyman_doors_windows_many_type`) VALUES (2, '3-5');
INSERT INTO `handyman_doors_windows_many` (`handyman_doors_windows_many_id`, `handyman_doors_windows_many_type`) VALUES (3, '6-9');
INSERT INTO `handyman_doors_windows_many` (`handyman_doors_windows_many_id`, `handyman_doors_windows_many_type`) VALUES (4, '10+');
