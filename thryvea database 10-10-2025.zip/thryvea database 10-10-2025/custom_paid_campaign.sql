INSERT INTO `custom_paid_campaign` (`custom_paid_campaign_id`, `custom_paid_campaign`) VALUES (1, 'Exclusive');
INSERT INTO `custom_paid_campaign` (`custom_paid_campaign_id`, `custom_paid_campaign`) VALUES (2, 'Shared');
