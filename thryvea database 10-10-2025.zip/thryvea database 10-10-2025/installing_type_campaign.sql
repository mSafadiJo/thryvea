INSERT INTO `installing_type_campaign` (`installing_type_campaign_id`, `installing_type_campaign`) VALUES (1, 'Install');
INSERT INTO `installing_type_campaign` (`installing_type_campaign_id`, `installing_type_campaign`) VALUES (2, 'Replace');
INSERT INTO `installing_type_campaign` (`installing_type_campaign_id`, `installing_type_campaign`) VALUES (3, 'Repair');
