INSERT INTO `property_type_campaign` (`property_type_campaign_id`, `property_type_campaign`) VALUES (1, 'Owned');
INSERT INTO `property_type_campaign` (`property_type_campaign_id`, `property_type_campaign`) VALUES (2, 'Rented');
INSERT INTO `property_type_campaign` (`property_type_campaign_id`, `property_type_campaign`) VALUES (3, 'Business');
