INSERT INTO `lead_traffic_sources` (`id`, `marketing_platform_id`, `name`, `created_at`, `updated_at`) VALUES (1, 27, 't1', '2025-08-21 04:22:39', '2025-08-25 10:57:01');
