INSERT INTO `_campaign_bathroomtype` (`campaign_bathroomtype_id`, `campaign_bathroomtype_type`) VALUES (1, 'Full Remodel');
INSERT INTO `_campaign_bathroomtype` (`campaign_bathroomtype_id`, `campaign_bathroomtype_type`) VALUES (2, 'Cabinets / Vanity');
INSERT INTO `_campaign_bathroomtype` (`campaign_bathroomtype_id`, `campaign_bathroomtype_type`) VALUES (3, 'Countertops');
INSERT INTO `_campaign_bathroomtype` (`campaign_bathroomtype_id`, `campaign_bathroomtype_type`) VALUES (4, 'Flooring');
INSERT INTO `_campaign_bathroomtype` (`campaign_bathroomtype_id`, `campaign_bathroomtype_type`) VALUES (5, 'Shower / Bath');
INSERT INTO `_campaign_bathroomtype` (`campaign_bathroomtype_id`, `campaign_bathroomtype_type`) VALUES (6, 'Sinks');
INSERT INTO `_campaign_bathroomtype` (`campaign_bathroomtype_id`, `campaign_bathroomtype_type`) VALUES (7, 'Toilet');
