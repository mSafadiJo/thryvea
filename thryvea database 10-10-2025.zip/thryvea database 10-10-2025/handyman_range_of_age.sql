INSERT INTO `handyman_range_of_age` (`handyman_range_of_age_id`, `handyman_range_of_age_type`) VALUES (1, '0-3');
INSERT INTO `handyman_range_of_age` (`handyman_range_of_age_id`, `handyman_range_of_age_type`) VALUES (2, '3-5');
INSERT INTO `handyman_range_of_age` (`handyman_range_of_age_id`, `handyman_range_of_age_type`) VALUES (3, '5-7');
INSERT INTO `handyman_range_of_age` (`handyman_range_of_age_id`, `handyman_range_of_age_type`) VALUES (4, '7 and above');
