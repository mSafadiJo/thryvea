INSERT INTO `lead_solor_sun_expouser_list` (`lead_solor_sun_expouser_list_id`, `lead_solor_sun_expouser_list_name`) VALUES (1, 'Full Sun');
INSERT INTO `lead_solor_sun_expouser_list` (`lead_solor_sun_expouser_list_id`, `lead_solor_sun_expouser_list_name`) VALUES (2, 'Partial Sun');
INSERT INTO `lead_solor_sun_expouser_list` (`lead_solor_sun_expouser_list_id`, `lead_solor_sun_expouser_list_name`) VALUES (3, 'Mostly Shaded');
INSERT INTO `lead_solor_sun_expouser_list` (`lead_solor_sun_expouser_list_id`, `lead_solor_sun_expouser_list_name`) VALUES (4, 'Not Sure');
