INSERT INTO `payment_type_method` (`payment_type_method_id`, `payment_type_method_type`) VALUES (1, 'Pre PayPal');
INSERT INTO `payment_type_method` (`payment_type_method_id`, `payment_type_method_type`) VALUES (2, 'Pre Credit Card');
INSERT INTO `payment_type_method` (`payment_type_method_id`, `payment_type_method_type`) VALUES (3, 'Post pay net 15 wire');
INSERT INTO `payment_type_method` (`payment_type_method_id`, `payment_type_method_type`) VALUES (4, 'Post pay net 30 wire');
INSERT INTO `payment_type_method` (`payment_type_method_id`, `payment_type_method_type`) VALUES (5, 'Post pay net 45 wire');
INSERT INTO `payment_type_method` (`payment_type_method_id`, `payment_type_method_type`) VALUES (6, 'Post pay net 15 eCheck');
INSERT INTO `payment_type_method` (`payment_type_method_id`, `payment_type_method_type`) VALUES (7, 'Post pay net 30 eCheck');
INSERT INTO `payment_type_method` (`payment_type_method_id`, `payment_type_method_type`) VALUES (8, 'Post pay net 45 eCheck');
