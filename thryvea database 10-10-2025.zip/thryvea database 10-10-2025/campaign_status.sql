INSERT INTO `campaign_status` (`campaign_status_id`, `campaign_status_name`) VALUES (1, 'Running');
INSERT INTO `campaign_status` (`campaign_status_id`, `campaign_status_name`) VALUES (2, 'Stopped');
INSERT INTO `campaign_status` (`campaign_status_id`, `campaign_status_name`) VALUES (3, 'Pending');
INSERT INTO `campaign_status` (`campaign_status_id`, `campaign_status_name`) VALUES (4, 'Pause');
