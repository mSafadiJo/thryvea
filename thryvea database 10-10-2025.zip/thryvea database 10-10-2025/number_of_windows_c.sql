INSERT INTO `number_of_windows_c` (`number_of_windows_c_id`, `number_of_windows_c_type`) VALUES (1, '1');
INSERT INTO `number_of_windows_c` (`number_of_windows_c_id`, `number_of_windows_c_type`) VALUES (2, '2');
INSERT INTO `number_of_windows_c` (`number_of_windows_c_id`, `number_of_windows_c_type`) VALUES (3, '3-5');
INSERT INTO `number_of_windows_c` (`number_of_windows_c_id`, `number_of_windows_c_type`) VALUES (4, '6-9');
INSERT INTO `number_of_windows_c` (`number_of_windows_c_id`, `number_of_windows_c_type`) VALUES (5, '10+');
