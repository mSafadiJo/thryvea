INSERT INTO `lead_nature_flooring_project` (`lead_nature_flooring_project_id`, `lead_nature_flooring_project_name`) VALUES (1, 'Install New Flooring');
INSERT INTO `lead_nature_flooring_project` (`lead_nature_flooring_project_id`, `lead_nature_flooring_project_name`) VALUES (2, 'Refinish Existing Flooring');
INSERT INTO `lead_nature_flooring_project` (`lead_nature_flooring_project_id`, `lead_nature_flooring_project_name`) VALUES (3, 'Repair Existing Flooring');
