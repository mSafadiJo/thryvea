INSERT INTO `lead_priority` (`lead_priority_id`, `lead_priority_name`) VALUES (1, 'Immediately');
INSERT INTO `lead_priority` (`lead_priority_id`, `lead_priority_name`) VALUES (2, 'Within 6 months');
INSERT INTO `lead_priority` (`lead_priority_id`, `lead_priority_name`) VALUES (3, 'Not Sure');
