INSERT INTO `period_campaign` (`period_campaign_id`, `period_campaign_name`) VALUES (1, 'Daily');
INSERT INTO `period_campaign` (`period_campaign_id`, `period_campaign_name`) VALUES (2, 'Weekly');
INSERT INTO `period_campaign` (`period_campaign_id`, `period_campaign_name`) VALUES (3, 'Monthly');
