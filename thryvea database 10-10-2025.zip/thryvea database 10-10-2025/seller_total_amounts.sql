INSERT INTO `seller_total_amounts` (`total_amounts_id`, `user_id`, `total_amounts_value`, `created_at`, `updated_at`) VALUES (1, 10, 689.00, '2025-04-25 10:02:41', '2025-05-09 15:34:56');
INSERT INTO `seller_total_amounts` (`total_amounts_id`, `user_id`, `total_amounts_value`, `created_at`, `updated_at`) VALUES (2, 13, 7308.93, '2025-07-31 13:05:49', '2025-10-08 08:52:17');
INSERT INTO `seller_total_amounts` (`total_amounts_id`, `user_id`, `total_amounts_value`, `created_at`, `updated_at`) VALUES (3, 16, 31851.64, '2025-07-31 13:15:14', '2025-10-08 19:41:25');
INSERT INTO `seller_total_amounts` (`total_amounts_id`, `user_id`, `total_amounts_value`, `created_at`, `updated_at`) VALUES (4, 14, 4242.23, '2025-08-13 03:10:39', '2025-10-09 07:50:32');
INSERT INTO `seller_total_amounts` (`total_amounts_id`, `user_id`, `total_amounts_value`, `created_at`, `updated_at`) VALUES (5, 26, 2532.68, '2025-09-15 05:03:16', '2025-10-09 11:27:48');
