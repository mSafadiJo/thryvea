INSERT INTO `door_typeproject_lead` (`door_typeproject_lead_id`, `door_typeproject_lead_type`) VALUES (1, 'Exterior\r\n');
INSERT INTO `door_typeproject_lead` (`door_typeproject_lead_id`, `door_typeproject_lead_type`) VALUES (2, 'Interior');
