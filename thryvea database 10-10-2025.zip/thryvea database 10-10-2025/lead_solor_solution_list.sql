INSERT INTO `lead_solor_solution_list` (`lead_solor_solution_list_id`, `lead_solor_solution_list_name`) VALUES (1, 'Solar Electricity for my Home');
INSERT INTO `lead_solor_solution_list` (`lead_solor_solution_list_id`, `lead_solor_solution_list_name`) VALUES (2, 'Solar Water Heating for my Home');
INSERT INTO `lead_solor_solution_list` (`lead_solor_solution_list_id`, `lead_solor_solution_list_name`) VALUES (3, 'Solar Electricity & Water Heating for my Home');
INSERT INTO `lead_solor_solution_list` (`lead_solor_solution_list_id`, `lead_solor_solution_list_name`) VALUES (4, 'Solar for my Business');
