INSERT INTO `lead_property_type_roofing` (`lead_property_type_roofing_id`, `lead_property_type_roofing_name`) VALUES (1, 'Residential');
INSERT INTO `lead_property_type_roofing` (`lead_property_type_roofing_id`, `lead_property_type_roofing_name`) VALUES (2, 'Commercial');
