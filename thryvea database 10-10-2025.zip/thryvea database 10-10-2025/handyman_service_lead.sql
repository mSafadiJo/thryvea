INSERT INTO `handyman_service_lead` (`handyman_service_lead_id`, `handyman_service_lead_type`) VALUES (1, 'Handyman Services');
INSERT INTO `handyman_service_lead` (`handyman_service_lead_id`, `handyman_service_lead_type`) VALUES (2, 'Install Child Proofing\r\n');
INSERT INTO `handyman_service_lead` (`handyman_service_lead_id`, `handyman_service_lead_type`) VALUES (3, 'Install / Replace weatherstripping');
