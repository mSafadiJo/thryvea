INSERT INTO `type_of_siding_lead` (`type_of_siding_lead_id`, `type_of_siding_lead_type`) VALUES (1, 'Vinyl Siding');
INSERT INTO `type_of_siding_lead` (`type_of_siding_lead_id`, `type_of_siding_lead_type`) VALUES (2, 'Brickface Siding');
INSERT INTO `type_of_siding_lead` (`type_of_siding_lead_id`, `type_of_siding_lead_type`) VALUES (3, 'Composite wood Siding');
INSERT INTO `type_of_siding_lead` (`type_of_siding_lead_id`, `type_of_siding_lead_type`) VALUES (4, 'Aluminium Siding');
INSERT INTO `type_of_siding_lead` (`type_of_siding_lead_id`, `type_of_siding_lead_type`) VALUES (5, 'Stoneface Siding');
INSERT INTO `type_of_siding_lead` (`type_of_siding_lead_id`, `type_of_siding_lead_type`) VALUES (6, 'Fiber Cement Siding');
