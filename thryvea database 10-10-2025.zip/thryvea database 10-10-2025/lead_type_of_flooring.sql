INSERT INTO `lead_type_of_flooring` (`lead_type_of_flooring_id`, `lead_type_of_flooring_name`) VALUES (1, 'Vinyl Linoleum Flooring');
INSERT INTO `lead_type_of_flooring` (`lead_type_of_flooring_id`, `lead_type_of_flooring_name`) VALUES (2, 'Tile Flooring');
INSERT INTO `lead_type_of_flooring` (`lead_type_of_flooring_id`, `lead_type_of_flooring_name`) VALUES (3, 'Hardwood Flooring');
INSERT INTO `lead_type_of_flooring` (`lead_type_of_flooring_id`, `lead_type_of_flooring_name`) VALUES (4, 'Laminate Flooring');
INSERT INTO `lead_type_of_flooring` (`lead_type_of_flooring_id`, `lead_type_of_flooring_name`) VALUES (5, 'Carpet');
