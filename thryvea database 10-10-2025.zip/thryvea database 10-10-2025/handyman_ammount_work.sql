INSERT INTO `handyman_ammount_work` (`handyman_ammount_work_id`, `handyman_ammount_work_type`) VALUES (1, 'A variety of projects');
INSERT INTO `handyman_ammount_work` (`handyman_ammount_work_id`, `handyman_ammount_work_type`) VALUES (2, 'A single project');
