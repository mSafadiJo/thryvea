INSERT INTO `user_role` (`role_id`, `role_type`, `created_at`, `updated_at`) VALUES (1, 'super admin', NULL, NULL);
INSERT INTO `user_role` (`role_id`, `role_type`, `created_at`, `updated_at`) VALUES (2, 'admin', NULL, NULL);
INSERT INTO `user_role` (`role_id`, `role_type`, `created_at`, `updated_at`) VALUES (3, 'Buyer', NULL, NULL);
INSERT INTO `user_role` (`role_id`, `role_type`, `created_at`, `updated_at`) VALUES (4, 'aggregator', NULL, NULL);
INSERT INTO `user_role` (`role_id`, `role_type`, `created_at`, `updated_at`) VALUES (5, 'seller', NULL, NULL);
