INSERT INTO `delivery_method` (`delivery_Method_id`, `delivery_Method_type`) VALUES (1, 'SMS');
INSERT INTO `delivery_method` (`delivery_Method_id`, `delivery_Method_type`) VALUES (2, 'Email');
INSERT INTO `delivery_method` (`delivery_Method_id`, `delivery_Method_type`) VALUES (3, 'CRM');
