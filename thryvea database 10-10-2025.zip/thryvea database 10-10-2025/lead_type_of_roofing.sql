INSERT INTO `lead_type_of_roofing` (`lead_type_of_roofing_id`, `lead_type_of_roofing_name`) VALUES (1, 'Asphalt Roofing');
INSERT INTO `lead_type_of_roofing` (`lead_type_of_roofing_id`, `lead_type_of_roofing_name`) VALUES (2, ' Wood Shake/Composite Roofing');
INSERT INTO `lead_type_of_roofing` (`lead_type_of_roofing_id`, `lead_type_of_roofing_name`) VALUES (3, ' Metal Roofing');
INSERT INTO `lead_type_of_roofing` (`lead_type_of_roofing_id`, `lead_type_of_roofing_name`) VALUES (4, 'Natural Slate Roofing');
INSERT INTO `lead_type_of_roofing` (`lead_type_of_roofing_id`, `lead_type_of_roofing_name`) VALUES (5, ' Tile Roofing');
