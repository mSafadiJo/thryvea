INSERT INTO `lead_walk_in_tub` (`lead_walk_in_tub_id`, `lead_walk_in_tub_name`) VALUES (1, 'Safety');
INSERT INTO `lead_walk_in_tub` (`lead_walk_in_tub_id`, `lead_walk_in_tub_name`) VALUES (2, 'Therapeutic');
INSERT INTO `lead_walk_in_tub` (`lead_walk_in_tub_id`, `lead_walk_in_tub_name`) VALUES (3, 'Others');
