INSERT INTO `lead_desired_featuers` (`lead_desired_featuers_id`, `lead_desired_featuers_name`) VALUES (1, 'Whirlpool');
INSERT INTO `lead_desired_featuers` (`lead_desired_featuers_id`, `lead_desired_featuers_name`) VALUES (2, 'Quick Water Release');
INSERT INTO `lead_desired_featuers` (`lead_desired_featuers_id`, `lead_desired_featuers_name`) VALUES (3, 'Soaking');
INSERT INTO `lead_desired_featuers` (`lead_desired_featuers_id`, `lead_desired_featuers_name`) VALUES (4, 'Air/Hydro Massager');
