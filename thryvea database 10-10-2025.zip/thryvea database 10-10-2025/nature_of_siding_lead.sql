INSERT INTO `nature_of_siding_lead` (`nature_of_siding_lead_id`, `nature_of_siding_lead_type`) VALUES (1, 'Siding for a new home');
INSERT INTO `nature_of_siding_lead` (`nature_of_siding_lead_id`, `nature_of_siding_lead_type`) VALUES (2, 'Siding for a new addition');
INSERT INTO `nature_of_siding_lead` (`nature_of_siding_lead_id`, `nature_of_siding_lead_type`) VALUES (3, 'Replace existing siding');
INSERT INTO `nature_of_siding_lead` (`nature_of_siding_lead_id`, `nature_of_siding_lead_type`) VALUES (4, 'Repair section(s) of siding');
