INSERT INTO `number_of_door_lead` (`number_of_door_lead_id`, `number_of_door_lead_type`) VALUES (1, '1');
INSERT INTO `number_of_door_lead` (`number_of_door_lead_id`, `number_of_door_lead_type`) VALUES (2, '2');
INSERT INTO `number_of_door_lead` (`number_of_door_lead_id`, `number_of_door_lead_type`) VALUES (3, '3');
INSERT INTO `number_of_door_lead` (`number_of_door_lead_id`, `number_of_door_lead_type`) VALUES (4, '4+');
