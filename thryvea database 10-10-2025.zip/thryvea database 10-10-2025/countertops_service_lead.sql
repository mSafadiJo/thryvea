INSERT INTO `countertops_service_lead` (`countertops_service_lead_id`, `countertops_service_lead_type`) VALUES (1, 'Granite');
INSERT INTO `countertops_service_lead` (`countertops_service_lead_id`, `countertops_service_lead_type`) VALUES (2, 'Solid Surface (e.g corian)');
INSERT INTO `countertops_service_lead` (`countertops_service_lead_id`, `countertops_service_lead_type`) VALUES (3, 'Marble');
INSERT INTO `countertops_service_lead` (`countertops_service_lead_id`, `countertops_service_lead_type`) VALUES (4, 'Wood (e.g butcher block)');
INSERT INTO `countertops_service_lead` (`countertops_service_lead_id`, `countertops_service_lead_type`) VALUES (5, 'Stainless Steel');
INSERT INTO `countertops_service_lead` (`countertops_service_lead_id`, `countertops_service_lead_type`) VALUES (6, 'Laminate');
INSERT INTO `countertops_service_lead` (`countertops_service_lead_id`, `countertops_service_lead_type`) VALUES (7, 'Concrete');
INSERT INTO `countertops_service_lead` (`countertops_service_lead_id`, `countertops_service_lead_type`) VALUES (8, 'Other Solid Stone (e.g Quartz)\r\n');
