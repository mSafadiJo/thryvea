INSERT INTO `lead_avg_money_electicity_list` (`lead_avg_money_electicity_list_id`, `lead_avg_money_electicity_list_name`) VALUES (1, '$51 - $100');
INSERT INTO `lead_avg_money_electicity_list` (`lead_avg_money_electicity_list_id`, `lead_avg_money_electicity_list_name`) VALUES (2, '$151 - $200');
INSERT INTO `lead_avg_money_electicity_list` (`lead_avg_money_electicity_list_id`, `lead_avg_money_electicity_list_name`) VALUES (3, '$201 - $300');
INSERT INTO `lead_avg_money_electicity_list` (`lead_avg_money_electicity_list_id`, `lead_avg_money_electicity_list_name`) VALUES (4, '$401 - $500');
INSERT INTO `lead_avg_money_electicity_list` (`lead_avg_money_electicity_list_id`, `lead_avg_money_electicity_list_name`) VALUES (5, '$500+');
INSERT INTO `lead_avg_money_electicity_list` (`lead_avg_money_electicity_list_id`, `lead_avg_money_electicity_list_name`) VALUES (6, '$0 - $50');
INSERT INTO `lead_avg_money_electicity_list` (`lead_avg_money_electicity_list_id`, `lead_avg_money_electicity_list_name`) VALUES (7, '$101 - $150');
INSERT INTO `lead_avg_money_electicity_list` (`lead_avg_money_electicity_list_id`, `lead_avg_money_electicity_list_name`) VALUES (8, '$301 - $400');
